package ar.edu.iua.soa.demo.repository;

import ar.edu.iua.soa.demo.model.Factura;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FacturaRepository extends JpaRepository<Factura, Integer> {
    public Factura getOneFacturaByIdFactura(Integer idFactura);
}
