package ar.edu.iua.soa.demo.services;

import ar.edu.iua.soa.demo.business.IFacturaBusiness;
import ar.edu.iua.soa.demo.exceptions.NotFoundException;
import ar.edu.iua.soa.demo.model.Factura;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(Constantes.URL_FACTURA)
public class FacturaRESTController {

    @Autowired
    private IFacturaBusiness facturaBusiness;

    @RequestMapping(value = { "", "/"}, method = RequestMethod.GET, produces = "application/json")
    public ResponseEntity<List<Factura>> getAllFacturas(){
        return new ResponseEntity<List<Factura>>(facturaBusiness.getAll(), HttpStatus.OK);
    }


    @RequestMapping(value = { "", "/" }, method = RequestMethod.POST, produces = "application/json")
    public ResponseEntity<Factura> addFactura(@RequestBody Factura factura){
        Factura fact = facturaBusiness.add(factura);
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set("location", "/facturas/" + factura.getIdFactura());
        return new ResponseEntity<Factura>(fact, responseHeaders, HttpStatus.CREATED);
    }

    @RequestMapping(value = {"/{idFactura}"}, method = RequestMethod.GET, produces = "application/json")
    public ResponseEntity<Factura> getFacturaById(@PathVariable("idFactura") int idFactura){
        try {
            return new ResponseEntity<Factura>(facturaBusiness.getFacturaByIdFactura(idFactura), HttpStatus.OK);
        }catch (NotFoundException e){
            return new ResponseEntity<Factura>(HttpStatus.NOT_FOUND);
        }
    }



}
