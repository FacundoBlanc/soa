package ar.edu.iua.soa.demo.dto;

public class FacturaDTO{
}
