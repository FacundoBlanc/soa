package ar.edu.iua.soa.demo.dto;

import java.util.Date;

public class OrdenDTO {
    private Integer idOrden;
    private CompradorDTO compradorDTO;
    private VendedorDTO vendedorDTO;
    private String estado;
    private ProductoDTO productoDTO;
    private Date fecha;

    public Integer getIdOrden() {
        return idOrden;
    }

    public void setIdOrden(Integer idOrden) {
        this.idOrden = idOrden;
    }

    public CompradorDTO getCompradorDTO() {
        return compradorDTO;
    }

    public void setCompradorDTO(CompradorDTO compradorDTO) {
        this.compradorDTO = compradorDTO;
    }

    public VendedorDTO getVendedorDTO() {
        return vendedorDTO;
    }

    public void setVendedorDTO(VendedorDTO vendedorDTO) {
        this.vendedorDTO = vendedorDTO;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public ProductoDTO getProductoDTO() {
        return productoDTO;
    }

    public void setProductoDTO(ProductoDTO productoDTO) {
        this.productoDTO = productoDTO;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
}
