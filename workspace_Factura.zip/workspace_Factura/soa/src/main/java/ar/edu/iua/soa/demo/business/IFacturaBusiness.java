package ar.edu.iua.soa.demo.business;

import ar.edu.iua.soa.demo.exceptions.NotFoundException;
import ar.edu.iua.soa.demo.model.Factura;

import java.util.List;

public interface IFacturaBusiness {
    public List<Factura> getAll();
    public Factura add (Factura factura);
    public Factura getFacturaByIdFactura (Integer idFactura) throws NotFoundException;
}
