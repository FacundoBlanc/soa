package ar.edu.iua.soa.demo.dto;

public class CompradorDTO {
    Integer id;
    String nombre;
    String apellido;
    DireccionDTO direccionDTO;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getApellido() {
        return apellido;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public DireccionDTO getDireccionDTO() {
        return direccionDTO;
    }

    public void setDireccionDTO(DireccionDTO direccionDTO) {
        this.direccionDTO = direccionDTO;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
}
