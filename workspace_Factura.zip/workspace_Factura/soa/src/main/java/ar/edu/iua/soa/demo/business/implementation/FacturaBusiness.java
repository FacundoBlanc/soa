package ar.edu.iua.soa.demo.business.implementation;

import ar.edu.iua.soa.demo.business.IFacturaBusiness;
import ar.edu.iua.soa.demo.dto.*;
import ar.edu.iua.soa.demo.exceptions.NotFoundException;
import ar.edu.iua.soa.demo.model.Factura;
import ar.edu.iua.soa.demo.repository.FacturaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class FacturaBusiness implements IFacturaBusiness {

    @Autowired
    private FacturaRepository facturaDAO;

    @Override
    public List<Factura> getAll(){

        return facturaDAO.findAll();
    }

    @Override
    public Factura add(Factura factura){
        // Integer idEnvio = 2;  // COLA DE FRANCO

        OrdenDTO ordenDTO = new OrdenDTO();
        CompradorDTO compradorDTO = new CompradorDTO();
        VendedorDTO vendedorDTO = new VendedorDTO();
        DireccionDTO direccionDTO = new DireccionDTO();
        ProductoDTO productoDTO = new ProductoDTO();

        direccionDTO.setBarrio("capilta");
        direccionDTO.setCalle("balcarce");
        direccionDTO.setCp("400");
        direccionDTO.setLocalidad("unquillo");
        direccionDTO.setNumero("1");
        direccionDTO.setProvincia("Buenos aires");
        productoDTO.setId(1);
        productoDTO.setNombre("leche");
        productoDTO.setPrecio(30);
        productoDTO.setSeller_id("1");
        vendedorDTO.setId(1);
        vendedorDTO.setNombre("Jeremias");
        vendedorDTO.setApellido("Leiton");
        vendedorDTO.setDireccionDTO(direccionDTO);
        compradorDTO.setId(1);
        compradorDTO.setNombre("facundo");
        compradorDTO.setApellido("Leiton");
        compradorDTO.setDireccionDTO(direccionDTO);
        ordenDTO.setIdOrden(1);
        ordenDTO.setCompradorDTO(compradorDTO);
        ordenDTO.setProductoDTO(productoDTO);
        ordenDTO.setVendedorDTO(vendedorDTO);
        ordenDTO.setEstado("OK");
        Date date = new Date();
        ordenDTO.setFecha(date);

        Factura factura1 = new Factura();
        factura1.setIdComprador(ordenDTO.getCompradorDTO().getId());
        factura1.setEstadoFactura(1);
        factura1.setFechaFactura(date);
        factura1.setIdPago(1);
        factura1.setIdVendedor(ordenDTO.getVendedorDTO().getId());
        factura1.setIdProducto(ordenDTO.getProductoDTO().getId());

        Factura fact = (Factura) facturaDAO.save(factura1);
        return fact;
    }

    @Override
    public Factura getFacturaByIdFactura(Integer idFactura) throws NotFoundException {
        Factura fac = facturaDAO.getOneFacturaByIdFactura(idFactura);
        if(fac == null){
            throw new NotFoundException();
        }else{
            return fac;
        }
    }
}

